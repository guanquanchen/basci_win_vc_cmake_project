// 7/10/5/4 2446 2025/05/01
// 广都
// wechat wo15985300747



#pragma once


/*

version:

win 10 vs2019 vc142/vc143
c++ 17

日志类 time_logger.cpp
文件操作类 path.cpp
json字符串类 jsoncpp
json与结构体相互转化类 xpack
utf8和 gbk互相转化 utf8_gbk.h
终端输出函数 print.cpp
线程池类  pool_number.cpp

// ------------------------------------------- 所有的输出公用一个全局锁，这样的话，打印就没有任何问题了，不会出现多线程错乱问题，性能低一点也行。

--------------------------------------------------------

提供了基于自定义字符串的宏，减少必要的传递数据

数据类型及其操作
文件类型及其操作
接口类型及其操作
界面类型及其操作


*/


# include <iostream>
#include <windows.h>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <vector>
#include <string>
#include <iostream>
#include <vector>
#include <string>
#include <type_traits>
#include <vector>
#include <algorithm>
#include <iterator>


// 基本数据类型集合
#include "main_type.cpp"
#include<utf8_gbk.h>
// 格式化参数为 字符串
#include <to_string.cpp>

#include<time_logger.cpp>
#include<print.cpp>
// ---------------------------------------------------------    ---------------------------------------------------------------------------
#include <get_vec1d_fuc.cpp>
#include <path.cpp>

template <typename T>
std::vector<T> shuffle_list_fuc(std::vector<T> vec) {
    // 直接返回，获得结果
    // return vec;

    std::random_device rd;  // Obtain a seed from the operating system
    std::mt19937 g(rd()); // Standard mersenne_twister_engine seeded with rd()
    std::shuffle(vec.begin(), vec.end(), g);
    return vec;
}

# include <iostream>
// #include <windows.h>
#include <string>
#include <vector>
#include <algorithm>
#include <tuple>
#include <iostream>
#include <vector>
// #include <path.cpp>
// #include "basci.cpp"

#include "xpack/json.h"
#include <json/jsoncpp.cpp>
#include <json/basci_function.cpp>
// #include<basci_c_charp.cpp>
#include <pool_number.cpp>

#include <cmath>
#include <vector>
#include "global_object.cpp"

