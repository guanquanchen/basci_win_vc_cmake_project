


/*
// 通用排序模板（返回新vector）
template <typename T, typename MemberType>
std::vector<T> get_sorted_list_fuc(const std::vector<T>& vec,  // 输入只读
                                MemberType T::* member_ptr,  // 成员指针
                                SortOrder order = SortOrder::Ascending)
{
    // 创建副本
    std::vector<T> sorted_vec(vec.begin(), vec.end());

    // 定义比较函数
    auto comparator = [member_ptr](const T& a, const T& b) {
        return a.*member_ptr < b.*member_ptr;
    };

    // 根据排序方向调整
    if (order == SortOrder::Descending) {
        comparator = [member_ptr](const T& a, const T& b) {
            return a.*member_ptr > b.*member_ptr;
        };
    }

    // 排序副本
    std::sort(sorted_vec.begin(), sorted_vec.end(), comparator);

    return sorted_vec;
}

*/


// ---------------------------------------------------------  提取要素，整理成整体    ---------------------------------------------------------------------------

// 通用提取函数模板
template <typename T, typename MemberType>
auto get_vector1d_fuc(const std::vector<T>& input_vec, MemberType T::* member_ptr)
    -> std::vector<MemberType>
{
    std::vector<MemberType> result;
    result.reserve(input_vec.size());

    std::transform(input_vec.begin(), input_vec.end(), std::back_inserter(result),
        [member_ptr](const T& obj) {
            return obj.*member_ptr; // 使用成员指针访问
        });

    return result;
}

#include <vector>
#include <algorithm>
#include <type_traits>

enum class SortOrder { Ascending, Descending };


// 版本1：处理结构体/类的成员变量排序
template <typename T, typename MemberType>
std::vector<T> get_sorted_list_fuc(const std::vector<T>& vec,
                                MemberType T::* member_ptr,
                                SortOrder order = SortOrder::Ascending)
{
    std::vector<T> sorted_vec(vec.begin(), vec.end());

    if (order == SortOrder::Ascending) {
        std::sort(sorted_vec.begin(), sorted_vec.end(),
            [member_ptr](const T& a, const T& b) {
                return a.*member_ptr < b.*member_ptr;
            });
    } else {
        std::sort(sorted_vec.begin(), sorted_vec.end(),
            [member_ptr](const T& a, const T& b) {
                return a.*member_ptr > b.*member_ptr;
            });
    }
    return sorted_vec;
}

// 版本2：处理基本类型直接排序
template <typename T>
std::vector<T> get_sorted_list_fuc(const std::vector<T>& vec,
                               SortOrder order = SortOrder::Ascending)
{
    std::vector<T> sorted_vec(vec.begin(), vec.end());

    if (order == SortOrder::Ascending) {
        std::sort(sorted_vec.begin(), sorted_vec.end());
    } else {
        std::sort(sorted_vec.rbegin(), sorted_vec.rend());
    }
    return sorted_vec;
}