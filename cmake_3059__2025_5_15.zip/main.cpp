// 通用win msvc 的基础函数库。


#include <basci.cpp>
void temp_x(){
    vector1d<int > vec1d_list = {1,2,3,5};
    print("vec1d_list",vec1d_list);
    vector2d<stringstd> str_list= {} ;
    str_list.push_back({"vec1d_list"});
    printline(str_list);
    vector3d<stringstd> str3_list = {};
    print(vec1d_list);
}



vector1d<int> log_task(int task_id) {
    TimeLogger_class logger;
    int num= 1;
    vector1d<int> num_list ={};
    num_list.push_back(num);
    for(int i = 0; i < num; ++i) {
        logger.get_now_time("Task:" + std::to_string(task_id) +
                            " Iter:" + std::to_string(i));
    }
    return num_list;
}


int main(int argc, char * const argv[]) {
    // system("chcp 65001");
    TimeLogger_class logger;
    logger.get_now_time("初始化");

    std::cout<<"main_path---->"<< main_path <<std::endl;

    int NUM_THREADS = get_cpu_numner_fuc();
    int TASKS_PER_THREAD = 1000;

    // 初始化线程池（CPU核心数 × 2）
    ThreadPool pool(NUM_THREADS);
    std::vector<std::future<vector1d<int>>> results;


    // 提交任务
    for(int i = 0; i < TASKS_PER_THREAD; ++i) {
        results.emplace_back(
            pool.enqueue(log_task, i)
        );
    }
    vector2d<int> num_2dlist={};
    // 等待所有任务完成
    try {
        for(auto& result : results) {
            vector1d<int> num_list=result.get();
            num_2dlist.push_back(num_list);
        }
    }
    catch(const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
    }

    // 压力测试验证
    // logger.get_flush_time("main_endl");
    printline("cc");

    // loggerc.get_now_time("cmain_endl");

    print(num_2dlist);

    return 0;
}





