# include <iostream>
#include <string>
#include <map>
#include <direct.h>


// stringstd get_main_path() {
// 	return getcwd(NULL, 0);
// }


#include "stdio.h"
#include "stdlib.h"
#include <sys/stat.h>

bool isfile(stringstd path) {

	stringstd fileName = path;
	struct _stat buf;
	int result;
	result = _stat(fileName.c_str(), &buf);

	if (_S_IFDIR & buf.st_mode) {
		return false;
	} else if (_S_IFREG & buf.st_mode) {
		return true;
	}
}
#include <io.h>


bool GetAllFolder(stringstd path, vector1d<stringstd> folder) {
	long hFile = 0;
	struct _finddata_t folderInfo;
	stringstd p;

	if ((hFile = _findfirst(p.assign(path).append("\\*").c_str(), &folderInfo)) != -1) {
		do {
			if ((folderInfo.attrib & _A_SUBDIR)) {
				if (strcmp(folderInfo.name, ".") != 0  &&  strcmp(folderInfo.name, "..") != 0) {
					stringstd re_path = p.assign(path).append("\\").append(folderInfo.name);
					re_path = re_path;
					folder.push_back(re_path);
					gdcout << re_path << gdendl;
				}
			} else {
				gdcout << "not a folder!\n";
			}
		} while (_findnext(hFile, &folderInfo)  == 0);
		_findclose(hFile); //ç»“æŸæŸ¥æ‰¾
	}

	return true;
}



void getFiles_funciton( stringstd path, vector1d<stringstd> files) {
	long   hFile   =   0;
	struct _finddata_t fileinfo;
	stringstd p;

	if ((hFile = _findfirst(p.assign(path).append("\\*").c_str(), &fileinfo)) !=  -1) {
		do {
			if ((fileinfo.attrib &  _A_SUBDIR)) {
				if (strcmp(fileinfo.name, ".") != 0  &&  strcmp(fileinfo.name, "..") != 0)
					getFiles_funciton( p.assign(path).append("\\").append(fileinfo.name), files);
			} else {
				stringstd re_path = path + "\\" + fileinfo.name;
				re_path = re_path;
				files.push_back(re_path);
			}
		} while (_findnext(hFile, &fileinfo)  == 0);
		_findclose(hFile);
	}
}






vector1d<stringstd> get_all_file(stringstd basci_path) {
	basci_path = basci_path; //
	vector1d<stringstd> folder;
	getFiles_funciton(basci_path, folder);
	// gdcout << folder << gdendl;
	// vector1d<stringstd> re_path_List;
	// return re_path_List;
	return folder;
}



#include <direct.h>
#include <iostream>
//using namespace std;

bool make_file_one(stringstd basci_path) {
	// basci_path = basci_path;
	if (0 != _mkdir(basci_path.c_str())) {
		return true;
	} else {
		return false;
	}
}

bool make_file(stringstd basci_path) {
	stringstd main_path;
	main_path.str = basci_path;
	main_path = main_path.replace("/", "\\");
	vector1d<stringstd> path_list;
	path_list = main_path.split("\\");
	stringstd now_path = path_list[0];
	int mi = 1;

	for(auto one:path_list){

		now_path = now_path + "/" + path_list[mi];
		make_file_one(now_path);
		mi = mi + 1;

	}
	// for (node *p = path_list.head->next; p != path_list.head; p = p->next) {
	// }


	return true;
}



#include <iostream>
#include <cstdio>

bool del_file(stringstd basci_path) {
	basci_path = basci_path;

	if (remove(basci_path.c_str()) == 0) {
		return true;
	} else {
		return false;
	}
}


vector1d<stringstd> path_split(stringstd path) {
	vector1d<stringstd> re_list;
	stringstd ustr;
	ustr.str = path;
	vector1d<stringstd> p1;
	ustr = ustr.replace("/", "\\");
	p1 = ustr.split("\\");
	stringstd ad;
	ad.str = p1[-1];

	if (ad.in(".")) {
		re_list.append(ustr(0, ustr.len() - ad.len() - 2));
		re_list.append(p1[-1]);
		re_list.append(ad.split(".")[-1]);

	} else {
		re_list.append(ustr(0, ustr.len() - ad.len()));
		re_list.append(p1[-1]);
	}

	return re_list;
}

#include <unistd.h>
#include <stringstd>
#include <fstream>
//using namespace std;

bool isexits(stringstd path) {
	ifstream f(path.c_str());
	return f.good();
}




void cgetFiles_funciton( stringstd path, string1d<stringstd> & files) {
	long   hFile   =   0;
	struct _finddata_t fileinfo;
	stringstd p;

	if ((hFile = _findfirst(p.assign(path).append("\\*").c_str(), &fileinfo)) !=  -1) {
		do {
			if ((fileinfo.attrib &  _A_SUBDIR)) {
				if (strcmp(fileinfo.name, ".") != 0  &&  strcmp(fileinfo.name, "..") != 0)
					cgetFiles_funciton( p.assign(path).append("\\").append(fileinfo.name), files);
			} else {
				stringstd re_path = path + "\\" + fileinfo.name;
				// re_path = re_path;
				files.push_back(re_path);
			}
		} while (_findnext(hFile, &fileinfo)  == 0);
		_findclose(hFile);
	}
}


std::string1d<stringstd> cget_all_file(stringstd path){
	std::string1d<stringstd> path_list;
	cgetFiles_funciton(path,path_list);
	return path_list;


}






int shutil_copy(stringstd source_dir1, stringstd destination_dir1){
	const char* source_dir = source_dir1.c_str();
	const char* destination_dir=destination_dir1.c_str();;
  	 ifstream infile(source_dir, ios::in | ios::binary);//二进制形式打开
	 if (infile.is_open() == 0) {//出错处理
		 gdcout << "文件" << source_dir << "打开失败" << gdendl;
		 return -1;
	 }
  	ofstream outfile(destination_dir, ios::out | ios::binary);//二进制形式打开
	 if (outfile.is_open() == 0) {//出错处理
	 	 gdcout << "文件" << destination_dir << "打开失败" << gdendl;
		  infile.close();//记得关闭
 		 return -1;
	 }
	  //开始读写
	 const int FLUSH_NUM = 1024 * 1024;//缓冲区大小设置为1M
	 char* ch = new(nothrow)char[FLUSH_NUM];
	 if (ch == NULL) {//出错处理
		  gdcout << "动态申请内存失败" << gdendl;
		  infile.close();//记得关闭
 		 outfile.close();//记得关闭
 		 return -1;
	 }
	 while (!infile.eof()) {
		  infile.read(ch, FLUSH_NUM);
		  outfile.write(ch, infile.gcount());//写入读入的成功个数
	 }
	 delete[]ch;//记得释放
	 infile.close();//记得关闭
	 outfile.close();//记得关闭
	 return 0;
}




#include <iostream>
#include <cstdio>

//using namespace std;

void os_rename(stringstd oldName, stringstd newName) {

  del_file(newName);
  int result = rename(oldName.c_str(), newName.c_str());
  // if (result == 0) {
  //   // gdcout << "File renamed successfully." << gdendl;
  // } else {
  //   gdcout << "Error renaming file." << gdendl;
  // }
}




#include <iostream>
#include <fstream>
#include <stringstd>
#include <cstringstd>
#include <sys/stat.h>
#include <sys/types.h>

//using namespace std;

bool copy_file(const char* filename, const char* folderPath) {
	// 给定一个路径，复制文件路径
    ifstream sourceFile(filename, ios::binary);
    if (!sourceFile) {
        // cerr << "Error: Failed to open source file!" << gdendl;
        return false;
    }
    stringstd destFilePath = stringstd(folderPath) + "/" + stringstd(filename);
    ofstream destFile(destFilePath.c_str(), ios::binary);
    if (!destFile) {
        // cerr << "Error: Failed to create destination file!" << gdendl;
        return false;
    }
    destFile << sourceFile.rdbuf();
    sourceFile.close();
    destFile.close();
    // gdcout << "File copied successfully!" << gdendl;
    return true;
}


