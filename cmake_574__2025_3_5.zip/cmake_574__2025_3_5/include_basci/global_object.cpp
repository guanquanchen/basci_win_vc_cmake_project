


std::string main_path=getExecutablePath();
