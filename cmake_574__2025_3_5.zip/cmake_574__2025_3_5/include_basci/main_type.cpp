#include <string>
#include <vector>

// 使用类型别名
using stringstd = std::string;
template<typename T>
using vector1d = std::vector<T>;
template<typename T>
using vector2d = std::vector<std::vector<T>>;
template<typename T>
using vector3d = std::vector<std::vector<std::vector<T>>>;

#define gdendl std::endl
#define gdcout std::cout