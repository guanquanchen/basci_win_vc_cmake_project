
#include <iostream>
#include <vector>
#include <string>
#include <iterator>

#if defined(_WIN32) || defined(_WIN64)
    #include <io.h>
    #include <direct.h>
    #define PATH_SEPARATOR "\\"
#else
    #include <dirent.h>
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <unistd.h>
    #define PATH_SEPARATOR "/"
#endif

class FileIterator {
public:
    FileIterator(const std::string &path) : path(path), is_end(true) {
        loadFiles();
    }

    // 迭代器解引用操作符
    const std::string& operator*() const {
        return current_file;
    }

    // 前缀递增操作符
    FileIterator& operator++() {
        if (it != files.end()) {
            current_file = *it;
            ++it;
            is_end = (it == files.end());
        }
        return *this;
    }

    // 后缀递增操作符
    FileIterator operator++(int) {
        FileIterator tmp = *this;
        ++(*this);
        return tmp;
    }

    // 检测是否到达结束
    bool operator!=(const FileIterator &other) const {
        return is_end != other.is_end;
    }

private:
    std::string path;
    std::vector<std::string> files;
    std::vector<std::string>::iterator it;
    std::string current_file;
    bool is_end;

    void loadFiles() {
#if defined(_WIN32) || defined(_WIN64)
        long hFile;
        struct _finddata_t fileinfo;
        std::string p;

        if ((hFile = _findfirst(p.assign(path).append(PATH_SEPARATOR).append("*").c_str(), &fileinfo)) != -1) {
            do {
                if (!(fileinfo.attrib & _A_SUBDIR)) {
                    files.push_back(p.assign(path).append(PATH_SEPARATOR).append(fileinfo.name));
                }
            } while (_findnext(hFile, &fileinfo) == 0);
            _findclose(hFile);
        }
#else
        DIR *dir;
        struct dirent *entry;
        if ((dir = opendir(path.c_str())) != nullptr) {
            while ((entry = readdir(dir)) != nullptr) {
                if (entry->d_type == DT_REG) {
                    files.push_back(path + PATH_SEPARATOR + entry->d_name);
                }
            }
            closedir(dir);
        }
#endif
        it = files.begin();
        if (it != files.end()) {
            current_file = *it;
            is_end = false;
        }
    }
};

// 函数返回迭代器
class FileCollection {
public:
    FileCollection(const std::string &path) : path(path) {}

    FileIterator begin() {
        return FileIterator(path);
    }

    FileIterator end() {
        return FileIterator("");
    }

private:
    std::string path;
};


