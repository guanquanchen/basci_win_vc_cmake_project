#pragma once

# include <iostream>
// #include <windows.h>
#include <string>

// using namespace std;

#include <iostream>
#include <vector>


// 基本数据类型集合
#include "main_type.cpp"



// template<typename T>
// void print(T DD){
//     std::cout << DD << std::endl;
// }


template<typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T>& vec)
{
    os << "[";
    for (size_t i = 0; i < vec.size(); ++i)
    {
        os << vec[i];
        if (i != vec.size() - 1)
            os << ", ";
    }
    os << "]";
    return os;
}


template<typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<std::vector<T>>& vec)
{
    os << "[";
    for (size_t i = 0; i < vec.size(); ++i)
    {
        os << vec[i];
        if (i != vec.size() - 1)
            os << ", ";
    }
    os << "]";
    return os;
}


template<typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<std::vector<stringstd>>& vec)
{
    os << "[";
    for (size_t i = 0; i < vec.size(); ++i)
    {
        os <<"\""<< vec[i]<<"\"";
        if (i != vec.size() - 1)
            os << ", ";
    }
    os << "]";
    return os;
}


template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<std::vector<std::vector<T>>>& vec) {
    os << "[";
    for (size_t i = 0; i < vec.size(); ++i) {
        os << vec[i];
        if (i != vec.size() - 1) {
            os << ", ";
        }
    }
    os << "]";
    return os;
}



// template<typename T>
// void print(T DD){
//     std::cout << DD << std::endl;
// }





#include <iostream>
#include <map>
#include <string>
#include <iomanip> // for std::fixed and std::setprecision



std::ostream& operator<<(std::ostream& os, const std::map<stringstd, double>& m) {
    os << "{";
    bool first = true;
    for (const auto& pair : m) {
        if (!first) {
            os << ",";
        }
        // Escape quotes within string keys (basic escaping)
        std::string escapedKey = pair.first;
        for (char& c : escapedKey) {
          if (c == '"') c = '\"'; // Simple quote escaping
        }

        os << "\"" << escapedKey << "\":" << std::fixed << std::setprecision(2) << pair.second; // Added precision control
        first = false;
    }
    os << "}";
    return os;
}







// void printline(std::string show_str="",std::string x="-"){
//     for(int i=0;i<=50;i++){
//        std::cout<<x;
//     }

//    std::cout<<"  "<<show_str<<"  ";

//     for(int i=50;i<=100;i++){
//        std::cout<<x;
//     }

//    std::cout<<std::endl;
// }


#include <algorithm>
#include <random>
#include <vector>

template <typename T>
std::vector<T> shuffle_list_fuc(std::vector<T> vec) {
    // 直接返回，获得结果
    // return vec;

    std::random_device rd;  // Obtain a seed from the operating system
    std::mt19937 g(rd()); // Standard mersenne_twister_engine seeded with rd()
    std::shuffle(vec.begin(), vec.end(), g);

    return vec;

}






#include <fstream>
#include <string>
#include <iostream>
#include <stdexcept>

bool write_StringToFileUTF8_fstream_fuc(const std::string& filename, const std::string& str) {
  std::fstream file(filename, std::ios::out | std::ios::binary); // binary mode is crucial for UTF-8

  if (!file.is_open()) {
    throw std::runtime_error("Error opening file: " + filename);
  }

  try {
    file.write(str.c_str(), str.length());
    file.close();
    return true;
  } catch (const std::exception& e) {
    std::cerr << "Error writing to file: " << e.what() << std::endl;
    return false;
  }
}

#include <iostream>
#include <filesystem>
#include <cstdlib> // for std::getenv
// namespace fs = std::filesystem;

std::string getExecutablePath() {
    try {

        return std::filesystem::current_path().string();

    } catch (const std::filesystem::filesystem_error& e) {

        std::cerr << "Error getting current working directory: " << e.what() << std::endl;
        return ""; // or throw the exception
    }
}


#include <filesystem> // Requires C++17 or later

// namespace fs = std::filesystem;

bool make_file(const std::string& path) {
  try {
    std::filesystem::create_directories(path); // Creates all necessary parent directories
  } catch (const std::filesystem::filesystem_error& e) {
    std::cerr << "Error creating directory '" << path << "': " << e.what() << std::endl;
    return false;
  }

  return true;
}




#include "global_object.cpp"





#include <chrono>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <string>

std::string get_now_time() {
  // 获取当前时间
  auto now = std::chrono::system_clock::now();
  std::time_t time = std::chrono::system_clock::to_time_t(now);

  // 将时间格式化为字符串
  std::stringstream ss;
  ss << std::put_time(std::localtime(&time), "%Y_%m_%d_%H_%M_%S");
  return ss.str();
}



// #include <chrono>
// #include <ctime>
// #include <iomanip>
// #include <sstream>
// #include <string>

// std::string get_now_time() {
//     // 获取当前时间
//     auto now = std::chrono::system_clock::now();
//     std::time_t time = std::chrono::system_clock::to_time_t(now);

//     // 使用 localtime_s 处理时间
//     struct tm local_tm;
//     localtime_s(&local_tm, &time); // 安全版本的 localtime

//     // 将时间格式化为字符串
//     std::stringstream ss;
//     ss << std::put_time(&local_tm, "%Y_%m_%d_%H_%M_%S");
//     return ss.str();
// }



//  cpp string  格式化
// -------------------------cpp折叠表达式----------------------------------
// cpp string 格式化
// #include <iostream>
// #include <sstream>
// #include <string>
// #include <fstream>
// #include <chrono>
// #include <ctime>
// #include <iomanip>
// #include <array> // for std::array

// // Helper function to convert any type to string.
// template <typename T>
// std::string toString(const T& value) {
//     std::stringstream ss;
//     ss << value;
//     return ss.str();
// }

// // Specialization for C-style strings
// template <size_t N>
// std::string toString(const char (&arr)[N]) {
//     return std::string(arr);
// }

// // Specialization for bool
// std::string toString(const bool& value) {
//     return value ? "true" : "false";
// }

// // Specialization for std::array
// template <typename T, std::size_t N>
// std::string toString(const std::array<T, N>& arr) {
//     std::stringstream ss;

//     ss << "[";

//     for (size_t i = 0; i < arr.size(); ++i) {
//         ss << toString(arr[i]);
//         if (i < arr.size() - 1) {
//             ss << ", ";
//         }
//     }

//     ss << "]";
//     return ss.str();
// }

// // Variadic template function to handle multiple arguments
// template <typename... Args>
// std::string getstr_fuc(const Args&... args) {
//     std::stringstream ssx;
//     (ssx << ... << toString(args));  // Fold expression since C++17
//     return ssx.str();
// }





// #include<time_logger.cpp>
// #include "xpack/json.h"

// #include <json/jsoncpp.cpp>
// #include <json/basci_function.cpp>
#include <string>
#include <iostream>
#include <vector>
#include <string>
#include <type_traits>


// #include<windows.h>
// using namespace std;


// template<typename T>
// std::ostream& operator<<(std::ostream& os, const std::vector<T>& vec)
// {
//     os << "[";
//     for (size_t i = 0; i < vec.size(); ++i)
//     {
//         os << vec[i];
//         if (i != vec.size() - 1)
//             os << ", ";
//     }
//     os << "]";
//     return os;
// }


// template<typename T>
// std::ostream& operator<<(std::ostream& os, const std::vector<std::vector<T>>& vec)
// {
//     os << "[";
//     for (size_t i = 0; i < vec.size(); ++i)
//     {
//         os << vec[i];
//         if (i != vec.size() - 1)
//             os << ", ";
//     }
//     os << "]";
//     return os;
// }



// template <typename T>
// std::ostream& operator<<(std::ostream& os, const std::vector<std::vector<std::vector<T>>>& vec) {
//     os << "[";
//     for (size_t i = 0; i < vec.size(); ++i) {
//         os << vec[i];
//         if (i != vec.size() - 1) {
//             os << ", ";
//         }
//     }
//     os << "]";
//     return os;
// }





template <typename T>
void printValue(const T& value) {
    std::cout << value<<" ";
}

template <>
void printValue(const bool& value) {
    std::cout << (value ? "True" : "False");
}


// template <typename T>
// void printValue(const std::vector<T>& vec) {
//     std::cout << "  [";
//     for (int i = 0; i < vec.size(); ++i) {
//         printValue(vec[i]);
//         if (i < vec.size() - 1) {
//             std::cout << ",";
//         }
//     }
//     std::cout << "] ";
// }



// class MyClass {
// public:
//     int data;
//     std::string name;
//     MyClass(int d, std::string n) : data(d), name(n) {}
// };


// void printValue(const MyClass& obj) {
//     std::cout << "  MyClass{data: " << obj.data << ", name: \"" << obj.name << "\"}";
// }


template <typename... Args>
void print(const Args&... args) {
    (printValue(args), ...);
    std::cout << std::endl;
}


template <typename... Args>
void printline(const Args&... args) {

    std::string x="-";

    for(int i=0;i<=50;i++){
        std::cout<<x;
    }
    // std::cout<<"  "<<show_str<<"  ";
    (printValue(args), ...);
    for(int i=50;i<=100;i++){
        std::cout<<x;
    }
    std::cout << std::endl;

}





//   llabf_first 用来测量高度宽度的，不用也可以，没用处
#include <vector>
#include <tuple>
#include <algorithm>
// #include <copy>



#include <iostream>
#include <vector>
#include <algorithm>






/*
auto myFunction_test(std::string uname) {
    // 使用初始化捕获来捕获uname变量
    return [uname = std::move(uname)]{
        struct {int id; std::string name;} temp = {11, uname}; // 定义并初始化一个匿名结构体
        return temp; // 返回这个临时对象
    }();
}

*/


// 只适合用一个头文件包裹起来 命名空间，避免冲突
// #include "path_system.h"
