#pragma once


// #include "CaculateData.h"
// #pragma comment(lib, "Caculate.lib")





#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <msclr\marshal_cppstd.h>
#include <algorithm>


// using namespace std;


// using namespace System;


using namespace msclr::interop;
using namespace System::Collections::Generic;
using namespace System::Runtime::InteropServices;


std::string c_sharp_to_cpp_str_fuc(System::String^ input){
    std::string utf8Input = marshal_as<std::string>(input);
    return utf8Input;
}


System::String^ cpp_to_c_sharp_str_fuc(std::string input){
    System::String^ managedResult = marshal_as<System::String^>(input);
    return managedResult;
}



System::String^ get_data_fuc( System::String^ input_data ){

    std::string ok_str = c_sharp_to_cpp_str_fuc(input_data);


    ok_str= ok_str+ " cpp";


    return cpp_to_c_sharp_str_fuc(ok_str);

}


std::string mergeStrings(const std::vector<std::string>& strings) {
    size_t totalLength = 0;
    for (const std::string& str : strings) {
        totalLength += str.size();
    }

    // 添加一个额外的空字符以结束字符串
    totalLength++;

    char* buffer = new char[totalLength];
    char* ptr = buffer;

    for (const std::string& str : strings) {
        std::copy(str.begin(), str.end(), ptr);
        ptr += str.size();
    }

    // 添加结束的空字符
    *ptr = '\0';

    std::string result(buffer, totalLength - 1);  // 不包括结束的空字符
    delete[] buffer;

    return result;
}



// 传递 cs 2d list to  cpp
std::vector<std::vector<std::string>>  get_2d_vector_string_array_fuc(cli::array<cli::array<System::String^>^>^ inputArray){
    std::vector<std::vector<std::string>> main_list;
    for(int i=0;i< inputArray->GetLength(0);i++){
        main_list.push_back({});

        for(int j=0;j<inputArray[i]->GetLength(0);j++){
            main_list[i].push_back(c_sharp_to_cpp_str_fuc(inputArray[i][j]));
        }
    }
    return main_list;
}


cli::array<cli::array<System::String^>^>^ get_2d_array_string_vector_fuc(std::vector<std::vector<std::string>> main_list){
      // 创建 C# 的二维数组，并将处理后的结果复制回去
     cli::array<cli::array<System::String^>^>^ resultArray = gcnew cli::array<cli::array<System::String^>^>(main_list.size());
     for (int i = 0; i < main_list.size(); i++){
         resultArray[i] = gcnew cli::array<System::String^>(main_list[i].size());
         for (int j = 0; j < main_list[i].size(); j++){
             resultArray[i][j] = cpp_to_c_sharp_str_fuc(main_list[i][j]);
         }
     }
     return resultArray;
}




std::vector<std::vector<double>>  get_2d_vector_double_array_fuc(cli::array<cli::array<double>^>^ inputArray){
    std::vector<std::vector<double>> main_list;


    for(int i=0;i< inputArray->GetLength(0);i++){
        main_list.push_back({});

        for(int j=0;j<inputArray[i]->GetLength(0);j++){
            main_list[i].push_back(inputArray[i][j]);
        }
    }
    return main_list;
}


// //  c# 的 数组转化为c++的 vector<string>
// std::vector<string>  get_ARRAY_csharp_double_1d_vector_fuc(cli::array<System::String^, 1>^ myArr)
// {
//     // int main_len = myArr->Length;
//      std::vector<string> main_list;
//     for(int i=0;i< myArr->Length;i++){
//         main_list.push_back(c_sharp_to_cpp_str_fuc(myArr[i]));
//     }
//     // String ^ str = cpp_to_c_sharp_str_fuc( mergeStrings(main_list));
//     // return str;
//     return main_list;
// }


cli::array<cli::array<double>^>^ get_2d_array_double_vector_fuc(std::vector<std::vector<double>> main_list){

      // 创建 C# 的二维数组，并将处理后的结果复制回去
     cli::array<cli::array<double>^>^ resultArray = gcnew cli::array<cli::array<double>^>(main_list.size());

     // cli::array<cli::array<System::String^>^>^ resultArray = gcnew cli::array<cli::array<System::String^>^>(main_list.size());

     for (int i = 0; i < main_list.size(); i++){
         resultArray[i] = gcnew cli::array<double>(main_list[i].size());
         for (int j = 0; j < main_list[i].size(); j++){
             resultArray[i][j] = main_list[i][j];
         }
     }

     return resultArray;
}



#include <memory>




cli::array<double>^ get_1d_vector_double_array_fuc(std::vector<double> main_list){
    int main_len = main_list.size();
      cli::array<double>^ resultArray= gcnew cli::array<double>(main_len);//= gcnew cli::array<double>^ (main_len);
    //cli::array<double>^ resultArray =  cli::array<double>^ (main_list.size());

     for (int i = 0; i < main_list.size(); i++){
        resultArray[i]= (main_list[i]);
            
     //.Add(main_list[i]);
     }
     return resultArray;
 }





//  c# 的 数组转化为c++的 vector<string>
std::vector<std::string>  get_vector_csharp_s_1d_array_fuc(cli::array<System::String^>^ myArr)
{
    // int main_len = myArr->Length;
     std::vector<std::string> main_list;
    for(int i=0;i< myArr->Length ;i++){
        main_list.push_back(c_sharp_to_cpp_str_fuc(myArr[i]));
    }
    // String ^ str = cpp_to_c_sharp_str_fuc( mergeStrings(main_list));
    // return str;
    return main_list;
}





// #include<basci_c_charp.cpp>


#include <iostream>
#include <fstream>
#include <string>


public ref class cut2d_class{
    private:
        // IntPtr aiTrainClass;
    public:
    int run_test(){
        std::cout<<"cpp_test"<<std::endl;
        return 1;
    }


    System::String^ get_data_fuc( System::String^ json_str_cs ){

        std::string json_str_temp = c_sharp_to_cpp_str_fuc(json_str_cs);
        // std::string point_list = c_sharp_to_cpp_str_fuc(point_list_cs);

        // write_txt_file_fuc("pp.json",json_str);
        // write_txt_file_fuc("ppint.json",point_list);

        std::string cpp_cut2d_json_str= "ssss";

        return cpp_to_c_sharp_str_fuc(cpp_cut2d_json_str);
    }

};



