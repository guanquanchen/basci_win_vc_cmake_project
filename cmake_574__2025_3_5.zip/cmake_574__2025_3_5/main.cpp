
# include <iostream>
// #include <windows.h>
#include <string>
#include <vector>
#include <algorithm>
#include <tuple>
#include <iostream>
#include <vector>

// #include <path.cpp>
#include "basci.cpp"
#include<time_logger.cpp>


#include "xpack/json.h"
#include <json/jsoncpp.cpp>
#include <json/basci_function.cpp>


// #include<basci_c_charp.cpp>
#include <pool_number.cpp>


void temp_x(){


    vector1d<int > dd = {1,2,3,5};
    print("dd",dd);


    vector2d<stringstd> str_list= {} ;
    str_list.push_back({"dd"});
    str_list.push_back({"uck"});

    printline(str_list);
    vector3d<stringstd> str3_list = {};

    printline(str3_list);

    printline("ok");


}

int main(int argc, char * const argv[]) {
    // system("chcp 65001");
    TimeLogger logger;
    logger.get_now_time("初始化");

    std::cout<<"main_path---->"<<main_path <<std::endl;


    logger.get_now_time("endl ");
    // system("pause");

    return 0;

}





/*

提供了基于自定义字符串的宏，减少必要的传递数据


数据类型及其操作

文件类型及其操作

接口类型及其操作
界面类型及其操作



*/








