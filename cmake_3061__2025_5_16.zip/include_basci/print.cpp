

#define STR50_LEN_STR "---------------------------------"

// template<typename T>
// std::ostream& operator<<(std::ostream& os, const std::vector<T>& vec)
// {
//     os << "[";
//     for (size_t i = 0; i < vec.size(); ++i)
//     {
//         os << vec[i];
//         if (i != vec.size() - 1)
//             os << ", ";
//     }
//     os << "]";
//     return os;
// }


// template<typename T>
// std::ostream& operator<<(std::ostream& os, const std::vector<std::vector<T>>& vec)
// {
//     os << "[";
//     for (size_t i = 0; i < vec.size(); ++i)
//     {
//         os << vec[i];
//         if (i != vec.size() - 1)
//             os << ", ";
//     }
//     os << "]";
//     return os;
// }


// template<typename T>
// std::ostream& operator<<(std::ostream& os, const std::vector<std::vector<stringstd>>& vec)
// {
//     os << "[";
//     for (size_t i = 0; i < vec.size(); ++i)
//     {
//         os <<"\""<< vec[i]<<"\"";
//         if (i != vec.size() - 1)
//             os << ", ";
//     }
//     os << "]";
//     return os;
// }


// template <typename T>
// std::ostream& operator<<(std::ostream& os, const std::vector<std::vector<std::vector<T>>>& vec) {
//     os << "[";
//     for (size_t i = 0; i < vec.size(); ++i) {
//         os << vec[i];
//         if (i != vec.size() - 1) {
//             os << ", ";
//         }
//     }
//     os << "]";
//     return os;
// }



// template<typename T>
// void print(T DD){
//     std::cout << DD << std::endl;
// }





#include <iostream>
#include <map>
#include <string>
#include <iomanip> // for std::fixed and std::setprecision



// std::ostream& operator<<(std::ostream& os, const std::map<stringstd, double>& m) {
//     os << "{";
//     bool first = true;
//     for (const auto& pair : m) {
//         if (!first) {
//             os << ",";
//         }
//         // Escape quotes within string keys (basic escaping)
//         std::string escapedKey = pair.first;
//         for (char& c : escapedKey) {
//           if (c == '"') c = '\"'; // Simple quote escaping
//         }

//         os << "\"" << escapedKey << "\":" << std::fixed << std::setprecision(2) << pair.second; // Added precision control
//         first = false;
//     }
//     os << "}";
//     return os;
// }







// void printline(std::string show_str="",std::string x="-"){
//     for(int i=0;i<=50;i++){
//        std::cout<<x;
//     }

//    std::cout<<"  "<<show_str<<"  ";

//     for(int i=50;i<=100;i++){
//        std::cout<<x;
//     }

//    std::cout<<std::endl;
// }






// template <typename T>
// void printValue(const T& value) {
//     std::cout << value<<" ";
// }

// template <>
// void printValue(const bool& value) {
//     std::cout << (value ? "True" : "False");
// }


// template <typename T>
// void printValue(const std::vector<T>& vec) {
//     std::cout << "  [";
//     for (int i = 0; i < vec.size(); ++i) {
//         printValue(vec[i]);
//         if (i < vec.size() - 1) {
//             std::cout << ",";
//         }
//     }
//     std::cout << "] ";
// }



// class MyClass {
// public:
//     int data;
//     std::string name;
//     MyClass(int d, std::string n) : data(d), name(n) {}
// };


// void printValue(const MyClass& obj) {
//     std::cout << "  MyClass{data: " << obj.data << ", name: \"" << obj.name << "\"}";
// }


// template <typename... Args>
// void print(const Args&... args) {
//     // return;
//     (printValue(args), ...);
//     std::cout << std::endl;
// }


// template <typename... Args>
// void printline(const Args&... args) {
//     // return;
//     printValue(STR50_LEN_STR);
//     (printValue(args), ...);
//     printValue(STR50_LEN_STR);
//     std::cout << std::endl;
// }

#include <vector>
#include <tuple>
#include <algorithm>
// #include <copy>

#include <iostream>
#include <vector>
#include <algorithm>


/*
auto myFunction_test(std::string uname) {
    // 使用初始化捕获来捕获uname变量
    return [uname = std::move(uname)]{
        struct {int id; std::string name;} temp = {11, uname}; // 定义并初始化一个匿名结构体
        return temp; // 返回这个临时对象
    }();
}

*/



// 容器输出工具（线程安全通过外层锁保证）
template<typename T>
std::ostream& operator<<(std::ostream& os, const vector1d<T>& vec) {
    os << "[";
    for (size_t i = 0; i < vec.size(); ++i) {
        os << vec[i];
        if (i != vec.size() - 1) os << ", ";
    }
    os << "]";
    return os;
}

template<typename T>
std::ostream& operator<<(std::ostream& os, const vector2d<T>& vec) {
    os << "[";
    for (size_t i = 0; i < vec.size(); ++i) {
        os << vec[i];
        if (i != vec.size() - 1) os << ", ";
    }
    os << "]";
    return os;
}

std::ostream& operator<<(std::ostream& os, const std::map<std::string, double>& m) {
    os << "{";
    bool first = true;
    for (const auto& pair : m) {
        if (!first) os << ",";
        os << "\"" << pair.first << "\":" << std::fixed << std::setprecision(2) << pair.second;
        first = false;
    }
    os << "}";
    return os;
}

// 线程安全打印工具
template <typename T>
void printValueToStream(std::ostringstream& oss, const T& value) {
    oss << value << " ";
}

template <>
void printValueToStream(std::ostringstream& oss, const bool& value) {
    oss << (value ? "True" : "False") << " ";
}

template <typename... Args>
void print(const Args&... args) {
    std::lock_guard<std::mutex> lock(TimeLogger_class::mtx);
    std::ostringstream oss;
    (printValueToStream(oss, args), ...);
    oss << std::endl;
    std::cout << oss.str();
}

template <typename... Args>
void printline(const Args&... args) {
    std::lock_guard<std::mutex> lock(TimeLogger_class::mtx);
    std::ostringstream oss;
    printValueToStream(oss, STR50_LEN_STR);
    (printValueToStream(oss, args), ...);
    printValueToStream(oss, STR50_LEN_STR);
    oss << std::endl;
    std::cout << oss.str();
}

/*


template<typename T>
void print_list(const vector1d<T>& vec)
{
    std::lock_guard<std::mutex> lock(TimeLogger_class::mtx);
    std::cout<<"[";
    for (size_t i = 0; i < vec.size(); ++i)
    {
        std::cout<< vec[i];
        if (i != vec.size() - 1)
            std::cout<< ", ";
    }
    std::cout<< "]";
    // return os;

}
*/


// 只适合用一个头文件包裹起来 命名空间，避免冲突
// #include "path_system.h"

#include <iostream>
#include <type_traits>

// 自定义 min_gd（支持任意类型和数量参数）
template <typename... Args>
auto min_gd(const Args&... args) {
    static_assert(sizeof...(args) > 0, "min_gd requires at least 1 argument");

    using CommonType = std::common_type_t<Args...>; // 推导公共类型
    CommonType min_val;
    bool is_first = true;

    // 用折叠表达式遍历所有参数
    ((is_first ? (min_val = args, is_first = false) : (args < min_val ? min_val = args : min_val)), ...);

    return min_val;
}

// 自定义 max_gd（支持任意类型和数量参数）
template <typename... Args>
auto max_gd(const Args&... args) {
    static_assert(sizeof...(args) > 0, "max_gd requires at least 1 argument");

    using CommonType = std::common_type_t<Args...>; // 推导公共类型
    CommonType max_val;
    bool is_first = true;

    // 用折叠表达式遍历所有参数
    ((is_first ? (max_val = args, is_first = false) : (args > max_val ? max_val = args : max_val)), ...);

    return max_val;
}


