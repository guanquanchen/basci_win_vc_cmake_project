
#include <iostream>
#include <string>
#include <vector>
#include "xpack/json.h" // Json包含这个头文件，xml则包含xpack/xml.h

/*
json 可以增加，减少，结构体也可以进行部分初始化，无需初始化所有


*/

// using namespace std;

struct User {
    int id;
    string name;
    std::vector<int> v;
    int uu=2;
    XPACK(O(id, v, name)); // 添加宏定义XPACK在结构体定义结尾
};

struct ddc{
    User dd;
    XPACK(O(dd));
};

int main(int argc, char *argv[]) {
    ddc uc;
    // 使用有效的JSON格式并正确引用变量名称
    // 使用xpack库来解码JSON数据
    try {
        string datac = "{\"v\":[12, 4],\"dd\": {\"id\": 12345,  \"name\": \"xpack\"}}";

        xpack::json::decode(datac, uc); // 使用正确的变量名
    } catch (const std::exception &e) {
        cerr << "Failed to decode JSON: " << e.what() << endl;
        return -1; // 返回错误代码
    }

    // 输出解码后的结果
    cout <<" uu "<<uc.dd.uu  <<"   "<< "User ID: " << uc.dd.id << "; Name: " << uc.dd.name << endl;

    // 将结构体编码回JSON格式
    string jsonc = xpack::json::encode(uc);
    cout << "Encoded JSON: " << jsonc << endl;

    return 0;
}


