
#pragma once

#include <string>
// #include "jsoncpp.cpp"
// #include "jsoncpp.cpp"
#include<json/jsoncpp.cpp>
#include <iostream>
#include <fstream>
// using namespace std;


std::string json_str_fuc(Json::Value root){

	Json::StreamWriterBuilder writerBuilder;
	std::unique_ptr<Json::StreamWriter> json_write(writerBuilder.newStreamWriter());
	std::ostringstream ss;
	json_write->write(root, &ss);
	// std::string strContent = ss.str();
	// std::cout << strContent << std::endl;
	return ss.str();
}

Json::Value str_json_fuc(std::string laser){
	// string laser = "{\"data\":[{\"createdAt\":\"2016-08-11 04:08:30\",\"dataFileName\":\"40dd8fcd-5e6d-4890-b620-88882d9d3977.data\",\"id\":0,\"mapInfo\":{\"gridHeight\":992,\"gridWidth\":992,\"originX\":-24.8,\"originY\":-24.8,\"resolution\":0.05000000074505806},\"name\":\"demo\",\"status\":4}],\"successed\":true}";
Json::Value tree;
Json::String err;
Json::CharReaderBuilder reader;
std::unique_ptr<Json::CharReader>const json_read(reader.newCharReader());
json_read->parse(laser.c_str(), laser.c_str() + laser.length(), &tree,&err);

	return tree;
}




Json::Value read_json_file(std::string json_file){
	// Json::Value
	Json::Reader reader;
	Json::Value root;
	//确认文件读取状态
		// string laser = "{\"data\":[{\"createdAt\":\"2016-08-11 04:08:30\",\"dataFileName\":\"40dd8fcd-5e6d-4890-b620-88882d9d3977.data\",\"id\":0,\"mapInfo\":{\"gridHeight\":992,\"gridWidth\":992,\"originX\":-24.8,\"originY\":-24.8,\"resolution\":0.05000000074505806},\"name\":\"demo\",\"status\":4}],\"successed\":true}";

	std::ifstream in(json_file, std::ios::binary);
	if (!in.is_open()){
		// cout << "Error opening file\n";

		return str_json_fuc("{}");
	}else{
		reader.parse(in, root);
		return root;
	}
}



std::string json_to_str_4_fuc(const Json::Value& writeJson) {
    Json::StyledWriter sw;
    std::stringstream ss;
    ss << sw.write(writeJson);
    return ss.str();
}



// 格式化，更好看
bool write_json_file(std::string jsonFileName,const Json::Value writeJson)
{
    std::ofstream jsonFile(jsonFileName.c_str(),std::ios::out);
    if(!jsonFile.is_open())
    {
        printf("OPEN %s ERROR\n",jsonFileName);
        return false;
    }
    else
    {
        Json::StyledWriter sw;
        jsonFile << sw.write(writeJson);
        jsonFile.close();
        return true;
    }

    return true;
}




/*

bool write_json_file(std::string file_name,Json::Value root){
	//格式化输出到文件
	ofstream os;             //实例化输出类
	os.open(file_name, std::ios::out); //打开并指定文件以输出方式打开（往文件里写）
	if (!os.is_open())               //检查文件打开情况
		// cout << "open file failed" << endl;
		return false;
	Json::StyledWriter sw;      //定义格式化输出
	sw['']
	os << sw.write(root);       //输出到文件
	os.close();                 //关闭文件

	return true;
}


bool write_json_file(std::string file_name, Json::Value root) {
    std::ofstream os;
    os.open(file_name, std::ios::out);
    if (!os.is_open()) {
        return false;
    }

    Json::StreamWriterBuilder builder;
    builder["indentation"] = "    "; // Four spaces
    std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());
    writer->write(root, &os);
    os.close();
    return true;
}

*/


template <typename T>
Json::Value  json_list(std::vector<T>  const &arr_list) {
	Json::Value array;
	for(auto array1: arr_list){
		// cout<<array1<<endl;
		array.append(array1);
	}
	return array;
}


