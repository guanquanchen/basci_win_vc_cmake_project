# by gd
# qq:1975767630

import xlrd         #1.2.0
import re           #
import os 
import shutil
import xlsxwriter
import time


def del_file(path_data):
    for i in os.listdir(path_data) :
        file_data = path_data + "\\" + i
        if os.path.isfile(file_data) == True:
            try:
                os.remove(file_data)
            except:
                pass
        else:
            try:
                del_file(file_data)
            except:
                pass
def get_all_file(path):
    # import os
    return_list=[]
    for root,dirs,files in os.walk(path,topdown=True):
        for file_one in files:
            use_path=root+'/'+file_one
            return_list.append(use_path.replace('/','\\'))
    return return_list


os.system('title 获得特定文件')

#                                                                       新建文件夹系统，并清空中介文件夹和最终成果文件夹中的所有文件。
#操作主路径。
main_path=os.getcwd()  
main_path=main_path.replace('\\','/')
print('操作主路径：    '+main_path)

write_path=main_path+'/当前查找得到的结果'

try:
    os.makedirs(write_path)
except:
    pass
del_file(write_path) #



# read_path=main_path+'/py文件汇总'

read_path=main_path

# 用来确保每次都是新的事情.
fp=open('程序运行错误记录.py','w')
fp.close()
# os.remove('程序运行错误记录.py')



read_path_list=get_all_file(read_path)

def get_all_txt(txt_path):
    return_list=[]
    lines  = open(txt_path,'r',encoding='gbk')
    for line in lines:
        # print(line)
        # line=line.replace(' ','')
        line=line.replace('\n','')
        # if 'def ' in line and '(' in line and ')' in line:
        #     return_list.append(str(line))
        return_list.append(str(line))
    lines.close()
    return return_list


for file_one in read_path_list:
    # print(file_one)
    if '.c' not in file_one:
        continue

    sign_i=0
    import traceback  
    # print(file_one)
    try:  
        txt_list=get_all_txt(file_one)
        # print(type(txt_list))
        for line_one in txt_list:
            # if 'def ' not in line and '(' not in line and ')' not in line:
            #     continue

            if  '::max' in line_one:  # 在这里添加你需要添加的内容，限定查找的内容，然后开始运行程序，在
                print(file_one,line_one)
                sign_i=1

        if sign_i==1:
            shutil.copy(file_one,write_path)

    except Exception as e:
        import time
        file=open('程序运行错误记录.py','a+',encoding='utf8')# 分割开的内容。
        file.write(file_one)
        file.write('\n'+str(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())))
        # print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))

        traceback.print_exc(file=open('程序运行错误记录.py','a+',encoding='utf8'))

        file.write('\n\n\n')
        file.close()
