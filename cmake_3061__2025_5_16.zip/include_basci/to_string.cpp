
//  cpp string  格式化
// -------------------------cpp折叠表达式----------------------------------
// cpp string 格式化
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <array> // for std::array

// Helper function to convert any type to string.
template <typename T>
std::string toString(const T& value) {
    std::stringstream ss;
    ss << value;
    return ss.str();
}

// Specialization for C-style strings
template <size_t N>
std::string toString(const char (&arr)[N]) {
    return std::string(arr);
}

// Specialization for bool
std::string toString(const bool& value) {
    return value ? "true" : "false";
}

// Specialization for std::array
template <typename T, std::size_t N>
std::string toString(const std::array<T, N>& arr) {
    std::stringstream ss;

    ss << "[";

    for (size_t i = 0; i < arr.size(); ++i) {
        ss << toString(arr[i]);
        if (i < arr.size() - 1) {
            ss << ", ";
        }
    }

    ss << "]";
    return ss.str();
}

// Variadic template function to handle multiple arguments
template <typename... Args>
std::string getstr_fuc(const Args&... args) {
    std::stringstream ssx;
    (ssx << ... << toString(args));  // Fold expression since C++17
    return ssx.str();
}


