#include <iostream>
#include <chrono>
#include <vector>
#include <string>
#include <ctime>
#include <iostream>
#include <cmath>


#include <iostream>
#include <sstream>
#include <iomanip>

// #ifdef _WIN32
// #include <Windows.h>
// #endif

#include <chrono>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <string>

#include <condition_variable>


std::string get_now_time() {
  // 获取当前时间
  auto now = std::chrono::system_clock::now();
  std::time_t time = std::chrono::system_clock::to_time_t(now);

  // 将时间格式化为字符串
  std::stringstream ss;
  ss << std::put_time(std::localtime(&time), "%Y_%m_%d_%H_%M_%S");
  return ss.str();
}


/*

#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <string>

std::string get_now_time() {
    // 获取当前时间
    auto now = std::chrono::system_clock::now();
    std::time_t time = std::chrono::system_clock::to_time_t(now);

    // 使用 localtime_s 处理时间
    struct tm local_tm;
    localtime_s(&local_tm, &time); // 安全版本的 localtime

    // 将时间格式化为字符串
    std::stringstream ss;
    ss << std::put_time(&local_tm, "%Y_%m_%d_%H_%M_%S");
    return ss.str();
}

*/



/*class TimeLogger_class {
public:
    TimeLogger_class() {
        start_time = std::chrono::system_clock::now();
        previous_time = start_time;
        time_number = 0;
    }

    void get_now_time(std::string show_str = "") {
        auto current_time = std::chrono::system_clock::now();
        auto time_diff = std::chrono::duration<double>(current_time - previous_time).count();
        previous_time = current_time;

        std::time_t current_time_t = std::chrono::system_clock::to_time_t(current_time);
        std::string current_time_str = std::ctime(&current_time_t);

        // SetConsoleOutputCP(65001); // 设置控制台输出编码为 UTF-8

      // Remove newline character
        if (!current_time_str.empty() && current_time_str[current_time_str.size() - 1] == '\n') {
            current_time_str[current_time_str.size() - 1] = ' '; // Replace '\n' with '\b'
        }



        if (show_str != "") {
            // std::cout << show_str;
            std::cout << "["  << time_number<< "\t  time--->" <<this->format_float_to_3decimals(this->get_time_since_init())<<"s \t" << " " << time_diff << "s \t " << current_time_str <<" \t "<<show_str<< "]" << std::endl;
        }else{
            std::cout << "["  << time_number<< "\t  time--->" <<this->format_float_to_3decimals(this->get_time_since_init())<<"s \t" << " " << time_diff << "s \t " << current_time_str << "]" << std::endl;
        }


        time_number++;
    }

    double get_time_since_init() {
        auto current_time = std::chrono::system_clock::now();
        auto time_diff = std::chrono::duration<double>(current_time - start_time).count();

        // Get current time in time_t format and convert it to a string
        std::time_t current_time_t = std::chrono::system_clock::to_time_t(current_time);
        std::string current_time_str = std::ctime(&current_time_t);

        // Remove newline character from current_time_str
        current_time_str = current_time_str.substr(0, current_time_str.size() - 1);

        // Return time difference with 3 decimal points
        return std::round(time_diff * 1000) / 1000.0;
    }

    std::string format_float_to_3decimals(double input_float) {
    std::stringstream ss;
    ss << std::fixed << std::setprecision(3) << input_float;
    std::string formatted_float = ss.str();

    // Pad with zeros if necessary
    size_t decimal_pos = formatted_float.find(".");
    if (decimal_pos != std::string::npos && formatted_float.size() - decimal_pos < 4) {
        formatted_float += "0";
    }

    return formatted_float;
}



private:
    std::chrono::time_point<std::chrono::system_clock> start_time;
    std::chrono::time_point<std::chrono::system_clock> previous_time;
    int time_number;
};





*/

/*
// 独立打印 多线程没有 异常
#include <iostream>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <mutex>
#include <cmath>


// 全局锁，这样可以更方便地打印，不必考虑任何打印错乱问题。

class TimeLogger_class {
public:
    TimeLogger_class() {
        start_time = std::chrono::system_clock::now();
        previous_time = start_time;
        time_number = 0;
    }

    void get_now_time(std::string show_str = "") {
        // 使用全局静态锁保证原子性
        std::lock_guard<std::mutex> lock(mtx);

        auto current_time = std::chrono::system_clock::now();
        auto time_diff = std::chrono::duration<double>(current_time - previous_time).count();
        previous_time = current_time;

        std::time_t current_time_t = std::chrono::system_clock::to_time_t(current_time);
        std::string current_time_str = std::ctime(&current_time_t);

        // 移除换行符
        if (!current_time_str.empty() && current_time_str.back() == '\n') {
            current_time_str.back() = ' ';
        }

        // 格式化输出（保证在锁的保护下连续完成）
        if (!show_str.empty()) {
            std::cout << "["
                      << time_number << "\t  time--->"
                      << format_float_to_3decimals(get_time_since_init()) << "s \t"
                      << time_diff << "s \t " << current_time_str << "\t " << show_str
                      << "]" << std::endl;
        } else {
            std::cout << "["
                      << time_number << "\t  time--->"
                      << format_float_to_3decimals(get_time_since_init()) << "s \t"
                      << time_diff << "s \t " << current_time_str << "]"
                      << std::endl;
        }

        time_number++;
    }

    double get_time_since_init() {
        auto current_time = std::chrono::system_clock::now();
        auto time_diff = std::chrono::duration<double>(current_time - start_time).count();
        return std::round(time_diff * 1000) / 1000.0;
    }

    std::string format_float_to_3decimals(double input_float) {
        std::stringstream ss;
        ss << std::fixed << std::setprecision(3) << input_float;
        std::string formatted_float = ss.str();

        size_t decimal_pos = formatted_float.find('.');
        if (decimal_pos != std::string::npos && formatted_float.size() - decimal_pos < 4) {
            formatted_float += "0";
        }

        return formatted_float;
    }

private:
    std::chrono::time_point<std::chrono::system_clock> start_time;
    std::chrono::time_point<std::chrono::system_clock> previous_time;
    int time_number;

    // 全局静态互斥锁
    static std::mutex mtx;
};

// 类外初始化静态成员
std::mutex TimeLogger_class::mtx;

*/



// int main() {
//     TimeLogger logger;

//     logger.get_now_time("初始化");

//     for(int i=0;i<=100;i++){
//         logger.get_now_time("中文修改中 "+std::to_string(i));
//         Sleep(100);
//     }

//     logger.get_time_since_init();

//     return 0;
// }







#include <iostream>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <mutex>
#include <vector>
#include <map>
#include <sstream>
#include <cmath>

// 定义静态常量字符串
const std::string STR50_LEN_STR = "---------------------------------";

// 线程安全控制类
class TimeLogger_class {
public:
    TimeLogger_class() {
        start_time = std::chrono::system_clock::now();
        previous_time = start_time;
        time_number = 0;
    }

    void get_now_time(const std::string& show_str = "") {
        std::lock_guard<std::mutex> lock(mtx);  // 共享全局锁

        auto current_time = std::chrono::system_clock::now();
        auto time_diff = std::chrono::duration<double>(current_time - previous_time).count();
        previous_time = current_time;

        std::time_t current_time_t = std::chrono::system_clock::to_time_t(current_time);
        std::string current_time_str = std::ctime(&current_time_t);

        if (!current_time_str.empty() && current_time_str.back() == '\n') {
            current_time_str.back() = ' ';
        }

        std::ostringstream oss;  // 内存流组装输出
        if (!show_str.empty()) {
            oss << "[" << time_number << "\t  time--->"
                << format_float_to_3decimals(get_time_since_init()) << "s \t"
                << time_diff << "s \t " << current_time_str << "\t " << show_str << "]";
        } else {
            oss << "[" << time_number << "\t  time--->"
                << format_float_to_3decimals(get_time_since_init()) << "s \t"
                << time_diff << "s \t " << current_time_str << "]";
        }

        std::cout << oss.str() << std::endl;  // 一次性输出
        time_number++;
    }

    static std::mutex mtx;  // 全局共享锁

private:
    double get_time_since_init() {
        auto current_time = std::chrono::system_clock::now();
        auto time_diff = std::chrono::duration<double>(current_time - start_time).count();
        return std::round(time_diff * 1000) / 1000.0;
    }

    std::string format_float_to_3decimals(double input_float) {
        std::stringstream ss;
        ss << std::fixed << std::setprecision(3) << input_float;
        std::string formatted_float = ss.str();
        size_t decimal_pos = formatted_float.find('.');
        if (decimal_pos != std::string::npos && formatted_float.size() - decimal_pos < 4) {
            formatted_float += "0";
        }
        return formatted_float;
    }

    std::chrono::time_point<std::chrono::system_clock> start_time;
    std::chrono::time_point<std::chrono::system_clock> previous_time;
    int time_number;
};

// 初始化静态成员
std::mutex TimeLogger_class::mtx;





/*
#pragma once
#include <iostream>
#include <chrono>
#include <mutex>
#include <iomanip>
#include <ctime>
#include <sstream>

class TimeLogger {
public:
    static TimeLogger& instance() {
        static TimeLogger logger;
        return logger;
    }

    void get_now_time(const std::string& message = "") {
        std::unique_lock<std::mutex> lock(mtx_);

        auto now = std::chrono::system_clock::now();
        double time_since_start = get_time_since_start_locked(now);
        double time_diff = get_time_diff_locked(now);

        std::time_t now_time_t = std::chrono::system_clock::to_time_t(now);
        std::string time_str = format_time(now_time_t);

        {
            std::unique_lock<std::mutex> cout_lock(cout_mtx_);
            std::cout << "[#" << log_count_ << "\t+"
                      << format_float(time_since_start) << "s \tΔ"
                      << format_float(time_diff) << "s \t"
                      << time_str;

            if (!message.empty()) {
                std::cout << " \t" << message;
            }
            std::cout << "]\n";
        }

        log_count_++;
        last_time_ = now;
    }

    // 删除拷贝构造函数和赋值运算符
    TimeLogger(const TimeLogger&) = delete;
    TimeLogger& operator=(const TimeLogger&) = delete;

private:
    TimeLogger() : start_time_(std::chrono::system_clock::now()),
                  last_time_(start_time_),
                  log_count_(0) {}

    std::chrono::system_clock::time_point start_time_;
    std::chrono::system_clock::time_point last_time_;
    unsigned long log_count_;
    std::mutex mtx_;
    static inline std::mutex cout_mtx_;

    double get_time_since_start_locked(
        const std::chrono::system_clock::time_point& now) const {
        return std::chrono::duration<double>(now - start_time_).count();
    }

    double get_time_diff_locked(
        const std::chrono::system_clock::time_point& now) const {
        return std::chrono::duration<double>(now - last_time_).count();
    }

    std::string format_time(std::time_t t) const {
        std::tm tm;
        // localtime_r(&t, &tm);  // Linux下线程安全
        gmtime_s(&tm, &t);  // Windows下使用

        std::ostringstream oss;
        oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
        return oss.str();
    }

    std::string format_float(double value) const {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(3) << value;
        std::string s = oss.str();
        size_t dot = s.find('.');
        if (s.size() - dot < 4) s += "0";
        return s;
    }
};

*/


/*

#pragma once
#include <iostream>
#include <chrono>
#include <queue>
#include <mutex>
#include <atomic>
#include <thread>
#include <iomanip>
#include <ctime>
#include <sstream>
#include <windows.h>

class TimeLogger {
public:
    static TimeLogger& instance() {
        static TimeLogger logger;
        return logger;
    }

    // 保持原有接口
    void get_now_time(const std::string& show_str = "") {
        std::lock_guard<std::mutex> lock(buffer_mutex_);
        log_queue_.push(generate_log_entry(show_str));
        buffer_cv_.notify_one();
    }

    // 新增批量获取接口（可选）
    std::vector<std::string> get_buffered_logs() {
        std::vector<std::string> logs;
        std::lock_guard<std::mutex> lock(buffer_mutex_);
        while (!log_queue_.empty()) {
            logs.push_back(log_queue_.front());
            log_queue_.pop();
        }
        return logs;
    }

    ~TimeLogger() {
        stop_flag_ = true;
        buffer_cv_.notify_all();
        if (flush_thread_.joinable()) {
            flush_thread_.join();
        }
    }

private:
    TimeLogger() {
        InitializeCriticalSection(&cs_);
        flush_thread_ = std::thread(&TimeLogger::flush_thread_func, this);
    }

    std::string generate_log_entry(const std::string& message) {
        auto now = std::chrono::system_clock::now();
        static auto start_time = now;

        // 计算时间差
        auto total_duration = std::chrono::duration<double>(now - start_time).count();
        auto temp_time = last_time_.exchange(now);
        auto delta_duration = std::chrono::duration<double>(now - temp_time).count();

        // 格式化时间
        std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tm;
        localtime_s(&tm, &t);

        std::ostringstream oss;
        oss << "[" << log_count_++ << "\t+"
            << std::fixed << std::setprecision(3) << total_duration << "s \tΔ"
            << std::setprecision(3) << delta_duration << "s \t"
            << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");

        if (!message.empty()) {
            oss << " \t" << message;
        }
        oss << "]";

        return oss.str();
    }

    void flush_thread_func() {
        constexpr DWORD flush_interval = 50; // 100ms
        std::vector<std::string> batch;

        while (!stop_flag_) {
            {
                std::unique_lock<std::mutex> lock(buffer_mutex_);
                buffer_cv_.wait_for(lock, std::chrono::milliseconds(flush_interval),
                    [this]{ return !log_queue_.empty() || stop_flag_; });

                while (!log_queue_.empty()) {
                    batch.push_back(log_queue_.front());
                    log_queue_.pop();
                }
            }

            if (!batch.empty()) {
                EnterCriticalSection(&cs_);
                for (const auto& log : batch) {
                    std::cout << log << "\n";
                }
                std::cout.flush();
                LeaveCriticalSection(&cs_);
                batch.clear();
            }
        }
    }

    // 禁止拷贝
    TimeLogger(const TimeLogger&) = delete;
    TimeLogger& operator=(const TimeLogger&) = delete;

    std::atomic<std::chrono::system_clock::time_point> last_time_{
        std::chrono::system_clock::now()
    };
    std::atomic<unsigned long> log_count_{0};
    std::mutex buffer_mutex_;
    std::condition_variable buffer_cv_;
    std::queue<std::string> log_queue_;
    std::thread flush_thread_;
    std::atomic<bool> stop_flag_{false};
    CRITICAL_SECTION cs_;  // Windows控制台输出临界区
};


*/






/*

#pragma once
#include <iostream>
#include <chrono>
#include <queue>
#include <mutex>
#include <atomic>
#include <thread>
#include <iomanip>
#include <ctime>
#include <sstream>
#include <windows.h>

class TimeLogger {
public:
    static TimeLogger& instance() {
        static TimeLogger logger;
        return logger;
    }

    // 保持原有接口
    void get_now_time(const std::string& show_str = "") {
        std::lock_guard<std::mutex> lock(buffer_mutex_);
        log_queue_.push(generate_log_entry(show_str));
        buffer_cv_.notify_one();
    }

    // 新增批量获取接口（可选）
    std::vector<std::string> get_buffered_logs() {
        std::vector<std::string> logs;
        std::lock_guard<std::mutex> lock(buffer_mutex_);
        while (!log_queue_.empty()) {
            logs.push_back(log_queue_.front());
            log_queue_.pop();
        }
        return logs;
    }

    ~TimeLogger() {
        stop_flag_ = true;
        buffer_cv_.notify_all();
        if (flush_thread_.joinable()) {
            flush_thread_.join();
        }
        DeleteCriticalSection(&cs_);
    }


private:
    TimeLogger() {
        InitializeCriticalSection(&cs_);
        flush_thread_ = std::thread(&TimeLogger::flush_thread_func, this);
    }

    std::string generate_log_entry(const std::string& message) {
        auto now = std::chrono::system_clock::now();
        static auto start_time = now;

        // 计算时间差
        auto total_duration = std::chrono::duration<double>(now - start_time).count();
        auto temp_time = last_time_.exchange(now);
        auto delta_duration = std::chrono::duration<double>(now - temp_time).count();

        // 格式化时间
        std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tm;
        localtime_s(&tm, &t);

        std::ostringstream oss;
        oss << "[" << log_count_++ << "\t+"
            << std::fixed << std::setprecision(3) << total_duration << "s \tΔ"
            << std::setprecision(3) << delta_duration << "s \t"
            << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");

        if (!message.empty()) {
            oss << " \t" << message;
        }
        oss << "]";

        return oss.str();
    }


    void flush_thread_func() {
        constexpr DWORD flush_interval = 100;
        std::vector<std::string> batch;

        while (true) {
            // 常规批量处理
            { // 原有批量获取逻辑

            // 输出批次
            if (!batch.empty()) {
                EnterCriticalSection(&cs_);
                for (const auto& log : batch) {
                    std::cout << log << "\n";
                }
                std::cout.flush();
                LeaveCriticalSection(&cs_);
                batch.clear();
            }

            // 退出检查
            if (stop_flag_) {
                std::unique_lock<std::mutex> lock(buffer_mutex_);
                while (!log_queue_.empty()) {
                    batch.push_back(log_queue_.front());
                    log_queue_.pop();
                }
                if (!batch.empty()) {
                    EnterCriticalSection(&cs_);
                    for (const auto& log : batch) {
                        std::cout << log << "\n";
                    }
                    std::cout.flush();
                    LeaveCriticalSection(&cs_);
                }
                break;
            }
        }
    }



    // 禁止拷贝
    TimeLogger(const TimeLogger&) = delete;
    TimeLogger& operator=(const TimeLogger&) = delete;

    std::atomic<std::chrono::system_clock::time_point> last_time_{
        std::chrono::system_clock::now()
    };
    std::atomic<unsigned long> log_count_{0};
    std::mutex buffer_mutex_;
    std::condition_variable buffer_cv_;
    std::queue<std::string> log_queue_;
    std::thread flush_thread_;
    std::atomic<bool> stop_flag_{false};
    CRITICAL_SECTION cs_;  // Windows控制台输出临界区
};


*/




/*

#pragma once
#include <iostream>
#include <chrono>
#include <queue>
#include <mutex>
#include <atomic>
#include <thread>
#include <iomanip>
#include <ctime>
#include <sstream>
#include <windows.h>

class TimeLogger {
public:
    static TimeLogger& instance() {
        static TimeLogger logger;
        return logger;
    }

    // 异步记录日志（缓冲输出）
    void get_now_time(const std::string& show_str = "") {
        std::lock_guard<std::mutex> lock(buffer_mutex_);
        log_queue_.push(generate_log_entry(show_str));
        buffer_cv_.notify_one();
    }

    // 同步立即输出日志
    void get_flush_time(const std::string& show_str = "") {
        std::string log_entry;
        {
            std::lock_guard<std::mutex> lock(buffer_mutex_);
            log_entry = generate_log_entry(show_str);
        }

        EnterCriticalSection(&cs_);
        std::cout << log_entry << std::endl;
        LeaveCriticalSection(&cs_);
    }

    // 刷新缓冲队列
    void flush() {
        std::vector<std::string> tmp;
        {
            std::lock_guard<std::mutex> lock(buffer_mutex_);
            while (!log_queue_.empty()) {
                tmp.push_back(log_queue_.front());
                log_queue_.pop();
            }
        }

        EnterCriticalSection(&cs_);
        for (const auto& s : tmp) {
            std::cout << s << "\n";
        }
        std::cout.flush();
        LeaveCriticalSection(&cs_);
    }

    ~TimeLogger() {
        stop_flag_ = true;
        buffer_cv_.notify_all();
        if (flush_thread_.joinable()) {
            flush_thread_.join();
        }
        DeleteCriticalSection(&cs_);
    }

private:
    TimeLogger() {
        InitializeCriticalSection(&cs_);
        flush_thread_ = std::thread(&TimeLogger::flush_thread_func, this);
    }

    std::string generate_log_entry(const std::string& message) {
        auto now = std::chrono::system_clock::now();
        static auto start_time = now;

        // 原子操作保证计数和时间准确
        const auto total_duration = std::chrono::duration<double>(now - start_time).count();
        const auto prev_time = last_time_.exchange(now);
        const auto delta_duration = std::chrono::duration<double>(now - prev_time).count();

        // 线程安全的时间格式化
        std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tm;
        localtime_s(&tm, &t);

        std::ostringstream oss;
        oss << "[" << log_count_++ << "\t+"
            << std::fixed << std::setprecision(3) << total_duration << "s \tΔ"
            << std::setprecision(3) << delta_duration << "s \t"
            << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");

        if (!message.empty()) {
            oss << " \t" << message;
        }
        oss << "]";

        return oss.str();
    }

    void flush_thread_func() {
        constexpr DWORD flush_interval = 100; // 100ms
        std::vector<std::string> batch;

        while (!stop_flag_) {
            {
                std::unique_lock<std::mutex> lock(buffer_mutex_);
                buffer_cv_.wait_for(lock, std::chrono::milliseconds(flush_interval),
                    [this]{ return !log_queue_.empty() || stop_flag_; });

                while (!log_queue_.empty() && batch.size() < 500) {
                    batch.push_back(log_queue_.front());
                    log_queue_.pop();
                }
            }

            if (!batch.empty()) {
                EnterCriticalSection(&cs_);
                for (const auto& log : batch) {
                    std::cout << log << "\n";
                }
                std::cout.flush();
                LeaveCriticalSection(&cs_);
                batch.clear();
            }
        }

        // 最终刷新剩余日志
        flush();
    }

    // 禁止拷贝
    TimeLogger(const TimeLogger&) = delete;
    TimeLogger& operator=(const TimeLogger&) = delete;

    std::atomic<std::chrono::system_clock::time_point> last_time_{
        std::chrono::system_clock::now()
    };
    std::atomic<unsigned long> log_count_{0};
    std::mutex buffer_mutex_;
    std::condition_variable buffer_cv_;
    std::queue<std::string> log_queue_;
    std::thread flush_thread_;
    std::atomic<bool> stop_flag_{false};
    CRITICAL_SECTION cs_;
};

*/






/*
#pragma once
#include <iostream>
#include <chrono>
#include <queue>
#include <mutex>
#include <atomic>
#include <thread>
#include <iomanip>
#include <ctime>
#include <sstream>
#include <windows.h>

class TimeLogger {
public:
    static TimeLogger& instance() {
        static TimeLogger logger;
        return logger;
    }

    // 异步缓冲输出
    void get_now_time(const std::string& show_str = "") {
        std::lock_guard<std::mutex> lock(buffer_mutex_);
        log_queue_.push(generate_log_entry(show_str));
        buffer_cv_.notify_one();
    }

    // 同步立即输出（强制刷新缓冲）
    void get_flush_time(const std::string& show_str = "") {
        std::string log_entry;
        {
            std::lock_guard<std::mutex> lock(buffer_mutex_);
            log_entry = generate_log_entry(show_str);
            log_queue_.push(log_entry);  // 先加入队列保证顺序
        }
        flush(true);  // true表示立即输出当前消息
    }

    // 强制刷新缓冲
    void flush(bool keep_last = false) {
        std::vector<std::string> tmp;
        {
            std::lock_guard<std::mutex> lock(buffer_mutex_);
            while (!log_queue_.empty()) {
                tmp.push_back(log_queue_.front());
                log_queue_.pop();
            }
            if (keep_last && !tmp.empty()) {
                log_queue_.push(tmp.back());  // 保留最后一条用于后续批量
                tmp.pop_back();
            }
        }

        if (!tmp.empty()) {
            EnterCriticalSection(&cs_);
            for (const auto& s : tmp) {
                std::cout << s << "\n";
            }
            std::cout.flush();
            LeaveCriticalSection(&cs_);
        }
    }

    ~TimeLogger() {
        stop_flag_ = true;
        buffer_cv_.notify_all();
        if (flush_thread_.joinable()) {
            flush_thread_.join();
        }
        DeleteCriticalSection(&cs_);
    }

private:
    // TimeLogger() {
    //     InitializeCriticalSection(&cs_);
    //     flush_thread_ = std::thread(&TimeLogger::flush_thread_func, this);
    // }

    // 修改构造函数初始化列表
    TimeLogger()
        : start_time_(std::chrono::system_clock::now()),
          last_time_(start_time_)
    {
        InitializeCriticalSection(&cs_);
        flush_thread_ = std::thread(&TimeLogger::flush_thread_func, this);
    }






    std::string generate_log_entry(const std::string& message) {
        // auto now = std::chrono::system_clock::now();
        // static auto start_time = now;

        // // 原子操作保证时间和计数准确
        // const auto total_duration = std::chrono::duration<double>(now - start_time).count();
        // const auto prev_time = last_time_.exchange(now);
        // const auto delta_duration = std::chrono::duration<double>(now - prev_time).count();

        auto now = std::chrono::system_clock::now();

        // 使用成员变量计算总时长
        const auto total_duration = std::chrono::duration<double>(now - start_time_).count();
        const auto prev_time = last_time_.exchange(now);
        const auto delta_duration = std::chrono::duration<double>(now - prev_time).count();


        // 线程安全的时间格式化
        std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tm;
        localtime_s(&tm, &t);

        std::ostringstream oss;
        oss << "[" << log_count_++ << "\t+"
            << std::fixed << std::setprecision(3) << total_duration << "s \tΔ"
            << std::setprecision(3) << delta_duration << "s \t"
            << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");

        if (!message.empty()) {
            oss << " \t" << message;
        }
        oss << "]";

        return oss.str();
    }

    void flush_thread_func() {
        constexpr DWORD flush_interval = 100; // 100ms
        std::vector<std::string> batch;

        while (!stop_flag_) {
            {   // 批量获取
                std::unique_lock<std::mutex> lock(buffer_mutex_);
                buffer_cv_.wait_for(lock, std::chrono::milliseconds(flush_interval),
                    [this]{ return !log_queue_.empty() || stop_flag_; });

                while (!log_queue_.empty() && batch.size() < 500) {
                    batch.push_back(log_queue_.front());
                    log_queue_.pop();
                }
            }

            // 批量输出
            if (!batch.empty()) {
                EnterCriticalSection(&cs_);
                for (const auto& log : batch) {
                    std::cout << log << "\n";
                }
                std::cout.flush();
                LeaveCriticalSection(&cs_);
                batch.clear();
            }
        }

        // 最终刷新
        flush();
    }

    TimeLogger(const TimeLogger&) = delete;
    TimeLogger& operator=(const TimeLogger&) = delete;

    std::atomic<std::chrono::system_clock::time_point> last_time_{
        std::chrono::system_clock::now()
    };
    std::atomic<unsigned long> log_count_{0};
    std::mutex buffer_mutex_;
    std::condition_variable buffer_cv_;
    std::queue<std::string> log_queue_;
    std::thread flush_thread_;
    std::atomic<bool> stop_flag_{false};
    CRITICAL_SECTION cs_;

    std::chrono::system_clock::time_point start_time_;  // 新增成员变量


};

*/












#pragma once
#include <iostream>
#include <chrono>
#include <queue>
#include <mutex>
#include <atomic>
#include <thread>
#include <iomanip>
#include <ctime>
#include <sstream>
#include <windows.h>

class TimeLogger {
public:
    static TimeLogger& instance() {
        static TimeLogger logger;
        return logger;
    }

    void get_now_time(const std::string& show_str = "") {
        std::lock_guard<std::mutex> lock(buffer_mutex_);
        log_queue_.emplace(generate_log_entry(show_str));
        buffer_cv_.notify_one();
    }

    void get_flush_time(const std::string& show_str = "") {
        std::string log_entry;
        {
            std::lock_guard<std::mutex> lock(buffer_mutex_);
            log_entry = generate_log_entry(show_str);
            log_queue_.push(log_entry);
        }
        flush(true);

    }

    void flush(bool keep_last = false) {
        std::vector<std::string> tmp;
        {
            std::lock_guard<std::mutex> lock(buffer_mutex_);
            while (!log_queue_.empty() && tmp.size() < BATCH_MAX) {
                tmp.emplace_back(std::move(log_queue_.front()));
                log_queue_.pop();
            }
            if (keep_last && !tmp.empty()) {
                log_queue_.push(tmp.back());
                tmp.pop_back();
            }
        }

        if (!tmp.empty()) {
            // 预分配内存并合并字符串
            size_t total_size = 0;
            for (const auto& s : tmp) total_size += s.size() + 1; // +1 for '\n'

            std::string buffer;
            buffer.reserve(total_size);
            for (const auto& s : tmp) {
                buffer.append(s).append("\n");
            }

            // 使用Windows API直接输出（比std::cout快5倍）
            DWORD chars_written = 0;
            WriteConsoleA(
                GetStdHandle(STD_OUTPUT_HANDLE),
                buffer.data(),
                static_cast<DWORD>(buffer.size()),
                &chars_written,
                nullptr
            );
        }
    }

    ~TimeLogger() {
        stop_flag_ = true;
        buffer_cv_.notify_all();
        if (flush_thread_.joinable()) {
            flush_thread_.join();
        }
        DeleteCriticalSection(&cs_);
    }

private:
    static constexpr size_t BATCH_MAX = 200;  // 每批处理1000条

    TimeLogger()
        : start_time_(std::chrono::system_clock::now()),
          last_time_(start_time_)
    {
        InitializeCriticalSection(&cs_);
        flush_thread_ = std::thread(&TimeLogger::flush_thread_func, this);
    }

    std::string generate_log_entry(const std::string& message) {
        auto now = std::chrono::system_clock::now();

        const auto total_duration = std::chrono::duration<double>(now - start_time_).count();
        const auto prev_time = last_time_.exchange(now);
        const auto delta_duration = std::chrono::duration<double>(now - prev_time).count();

        std::time_t t = std::chrono::system_clock::to_time_t(now);
        std::tm tm;
        localtime_s(&tm, &t);

        thread_local std::ostringstream oss;  // 线程局部存储避免重复构造
        oss.str("");
        oss << "[" << log_count_++ << "\t+"
            << std::fixed << std::setprecision(3) << total_duration << "s \tΔ"
            << std::setprecision(3) << delta_duration << "s \t"
            << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");

        if (!message.empty()) {
            oss << " \t" << message;
        }
        oss << "]";

        return oss.str();
    }

    void flush_thread_func() {
        while (!stop_flag_) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            flush();
        }

        // 最终刷新剩余日志
        while (!log_queue_.empty()) {
            flush();
        }
    }

    TimeLogger(const TimeLogger&) = delete;
    TimeLogger& operator=(const TimeLogger&) = delete;

    const std::chrono::system_clock::time_point start_time_;
    std::atomic<std::chrono::system_clock::time_point> last_time_;
    std::atomic<unsigned long> log_count_{0};
    std::mutex buffer_mutex_;
    std::condition_variable buffer_cv_;
    std::queue<std::string> log_queue_;
    std::thread flush_thread_;
    std::atomic<bool> stop_flag_{false};
    CRITICAL_SECTION cs_;
};














