/*
#include <iostream>
#include <vector>
#include <string>
#include <iterator>

#if defined(_WIN32) || defined(_WIN64)
    #include <io.h>
    #include <direct.h>
    #define PATH_SEPARATOR "\\"
#else
    #include <dirent.h>
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <unistd.h>
    #define PATH_SEPARATOR "/"
#endif

class FileIterator {
public:
    FileIterator(const std::string &path) : path(path), is_end(true) {
        loadFiles();
    }

    // 迭代器解引用操作符
    const std::string& operator*() const {
        return current_file;
    }

    // 前缀递增操作符
    FileIterator& operator++() {
        if (it != files.end()) {
            current_file = *it;
            ++it;
            is_end = (it == files.end());
        }
        return *this;
    }

    // 后缀递增操作符
    FileIterator operator++(int) {
        FileIterator tmp = *this;
        ++(*this);
        return tmp;
    }

    // 检测是否到达结束
    bool operator!=(const FileIterator &other) const {
        return is_end != other.is_end;
    }

private:
    std::string path;
    std::vector<std::string> files;
    std::vector<std::string>::iterator it;
    std::string current_file;
    bool is_end;

    void loadFiles() {
#if defined(_WIN32) || defined(_WIN64)
        long hFile;
        struct _finddata_t fileinfo;
        std::string p;

        if ((hFile = _findfirst(p.assign(path).append(PATH_SEPARATOR).append("*").c_str(), &fileinfo)) != -1) {
            do {
                if (!(fileinfo.attrib & _A_SUBDIR)) {
                    files.push_back(p.assign(path).append(PATH_SEPARATOR).append(fileinfo.name));
                }
            } while (_findnext(hFile, &fileinfo) == 0);
            _findclose(hFile);
        }
#else
        DIR *dir;
        struct dirent *entry;
        if ((dir = opendir(path.c_str())) != nullptr) {
            while ((entry = readdir(dir)) != nullptr) {
                if (entry->d_type == DT_REG) {
                    files.push_back(path + PATH_SEPARATOR + entry->d_name);
                }
            }
            closedir(dir);
        }
#endif
        it = files.begin();
        if (it != files.end()) {
            current_file = *it;
            is_end = false;
        }
    }
};

// 函数返回迭代器
class FileCollection {
public:
    FileCollection(const std::string &path) : path(path) {}

    FileIterator begin() {
        return FileIterator(path);
    }

    FileIterator end() {
        return FileIterator("");
    }

private:
    std::string path;
};


*/




#include <fstream>
#include <string>
#include <iostream>
#include <stdexcept>

bool write_StringToFileUTF8_fstream_fuc(const std::string& filename, const std::string& str) {
  std::fstream file(filename, std::ios::out | std::ios::binary); // binary mode is crucial for UTF-8

  if (!file.is_open()) {
    throw std::runtime_error("Error opening file: " + filename);
  }

  try {
    file.write(str.c_str(), str.length());
    file.close();
    return true;
  } catch (const std::exception& e) {
    std::cerr << "Error writing to file: " << e.what() << std::endl;
    return false;
  }
}

#include <iostream>
#include <filesystem>
#include <cstdlib> // for std::getenv
// namespace fs = std::filesystem;

std::string getExecutablePath() {
    try {
        return std::filesystem::current_path().string();
    } catch (const std::filesystem::filesystem_error& e) {
        std::cerr << "Error getting current working directory: " << e.what() << std::endl;
        return ""; // or throw the exception
    }
}


#include <filesystem> // Requires C++17 or later

// namespace fs = std::filesystem;

bool make_file(const std::string& path) {
  try {
    std::filesystem::create_directories(path); // Creates all necessary parent directories
  } catch (const std::filesystem::filesystem_error& e) {
    std::cerr << "Error creating directory '" << path << "': " << e.what() << std::endl;
    return false;
  }

  return true;
}






// --------------------------------------------------------- 获得文件列表   ---------------------------------------------------------------------------
void get_all_file_func(const std::string& rootpath, vector1d<stringstd>& path_list) {
    WIN32_FIND_DATA findFileData;
    HANDLE hFind = INVALID_HANDLE_VALUE;

    // 构造搜索路径
    std::string searchPath = rootpath + "\\*";

    // 开始查找文件
    hFind = FindFirstFile(searchPath.c_str(), &findFileData);
    if (hFind == INVALID_HANDLE_VALUE) {
        std::cerr << "FindFirstFile failed for path: " << rootpath << std::endl;
        return;
    }

    // 遍历文件夹中的文件和子文件夹
    do {
        // 忽略 "." 和 ".."
        if (strcmp(findFileData.cFileName, ".") == 0 || strcmp(findFileData.cFileName, "..") == 0) {
            continue;
        }

        // 构造完整路径
        std::string fullPath = rootpath + "\\" + findFileData.cFileName;

        // 如果是文件夹，递归调用
        if (findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            get_all_file_func(fullPath, path_list);
        } else {
            // 如果是文件，添加到路径列表中
            path_list.push_back(gbktoutf8(fullPath));
        }
    } while (FindNextFile(hFind, &findFileData) != 0);

    // 关闭查找句柄
    FindClose(hFind);
}



vector1d<stringstd> get_all_file(stringstd path ){
    vector1d<stringstd> path_list;
    get_all_file_func(path,path_list);
    // get_all_file_fuc_utf8(path,path_list);
    return path_list;
}






#include <iostream>
#include <vector>
#include <string>
#include <windows.h>

std::vector<std::string> getFileNames_one_fuc(const std::string& path) {
    std::vector<std::string> fileNames;

    // 构造搜索路径（支持通配符*）
    std::string searchPath = path + "\\*";

    // 查找第一个文件
    WIN32_FIND_DATAA findFileData;
    HANDLE hFind = FindFirstFileA(searchPath.c_str(), &findFileData);

    if (hFind == INVALID_HANDLE_VALUE) {
        std::cerr << "Error: Unable to open directory: " << path << std::endl;
        return fileNames;
    }

    do {
        // 忽略 "." 和 ".." 目录
        if (strcmp(findFileData.cFileName, ".") == 0 || strcmp(findFileData.cFileName, "..") == 0) {
            continue;
        }

        // 如果是文件，添加到列表中
        if (!(findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
            fileNames.push_back(findFileData.cFileName);
        }
    } while (FindNextFileA(hFind, &findFileData) != 0);

    // 关闭查找句柄
    FindClose(hFind);

    return fileNames;
}
